duyun5 = [1, None, None]
duyun4 = [2, duyun5, None]
duyun3 = [3, duyun4, None]
duyun2 = [4, duyun3, None]
duyun1 = [5, duyun2, None]

duyun5[2] = duyun4
duyun4[2] = duyun3
duyun3[2] = duyun2
duyun2[2] = duyun1

duyun5=append(duyun4, 10)
print("İrəli:")
cari = duyun1
while cari is not None:
    print(f"{cari[0]}")
    cari = cari[1]  

print("Geri:")
cari = duyun5
while cari is not None:
    print(f"{cari[0]}")
    cari = cari[2]  
   