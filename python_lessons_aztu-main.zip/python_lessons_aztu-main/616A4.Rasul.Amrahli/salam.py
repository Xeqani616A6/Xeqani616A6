print("salam dunya")
