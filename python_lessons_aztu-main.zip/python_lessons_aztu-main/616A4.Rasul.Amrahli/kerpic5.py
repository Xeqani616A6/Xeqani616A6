list=[1,2,3,4,5]
x=int(input("eded. "))
print(list[x])
