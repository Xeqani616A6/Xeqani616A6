a=[1,2,3,4,5,5]
b=[3,4,5,6,7]
c=list(set(a) & set(b))
print(c)
